package com.iptviluminaty.arcangel;

import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Toast;
import androidx.annotation.OptIn;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.datasource.DefaultHttpDataSource;
import com.iptviluminaty.arcangel.databinding.ActivityMainBinding;

@UnstableApi
public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private ExoPlayer player;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Pantalla siempre encendida para ver la TV sin interrupciones
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        String urlFinal = getIntent().getStringExtra("URL_FINAL");

        if (urlFinal != null && !urlFinal.isEmpty()) {
            setupPlayer(urlFinal);
        } else {
            Toast.makeText(this, "URL no válida, cielo 😅", Toast.LENGTH_SHORT).show();
            finish();
        }
    }
@OptIn(markerClass = UnstableApi.class)
private void setupPlayer(String url) {
    // 1. Creamos la fábrica de datos con esteroides
    DefaultHttpDataSource.Factory dataSourceFactory = new DefaultHttpDataSource.Factory()
            // Usamos el User-Agent que usa IPTV Smarters o VLC en Android
            .setUserAgent("VLC/3.0.13 LibVLC/3.3.0")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000) // 15 segundos de espera para conectar
            .setReadTimeoutMs(15000);

    // 2. Agregamos cabeceras adicionales (Trick para saltar bloqueos de host)
    // Algunos servidores verifican que el "Referer" sea el mismo host
    java.util.Map<String, String> defaultRequestProperties = new java.util.HashMap<>();
    defaultRequestProperties.put("Accept", "*/*");
    defaultRequestProperties.put("Connection", "keep-alive");
    dataSourceFactory.setDefaultRequestProperties(defaultRequestProperties);

    // 3. Configuramos el MediaSource para que soporte HLS y otros formatos automáticamente
    DefaultMediaSourceFactory mediaSourceFactory = new DefaultMediaSourceFactory(this)
            .setDataSourceFactory(dataSourceFactory);

    player = new ExoPlayer.Builder(this)
            .setMediaSourceFactory(mediaSourceFactory)
            .build();
    
    binding.playerView.setPlayer(player);

    // Listener mejorado para ver el error real en el Toast
    player.addListener(new Player.Listener() {
        @Override
        public void onPlayerError(PlaybackException error) {
            String causa = error.getErrorCodeName();
            Toast.makeText(MainActivity.this, "Error: " + causa + " ⚠️", Toast.LENGTH_LONG).show();
        }
    });

    MediaItem mediaItem = MediaItem.fromUri(url);
    player.setMediaItem(mediaItem);
    player.prepare();
    player.setPlayWhenReady(true);
}


    @Override
    protected void onResume() {
        super.onResume();
        if (player != null) player.play();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (player != null) player.pause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) {
            player.release();
            player = null;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        this.binding = null;
    }
}
