package com.iptviluminaty.arcangel;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class M3UParser {

    public static List<Channel> parse(String m3uContent) {
        List<Channel> channels = new ArrayList<>();
        
        if (m3uContent == null || m3uContent.isEmpty()) return channels;

        // CORRECCIÓN: Rompemos por cualquier tipo de salto de línea (\n, \r\n o \r)
        // Esto es vital para archivos grandes descargados por partes
        String[] lines = m3uContent.split("\\r?\\n");
        
        String name = "";
        String logo = "";
        String category = "Sin Categoría";

        for (String line : lines) {
            line = line.trim();
            
            // Saltamos líneas vacías o la cabecera #EXTM3U
            if (line.isEmpty() || line.startsWith("#EXTM3U")) continue;

            if (line.startsWith("#EXTINF")) {
                // 1. Extraer Logo y Categoría con regex mejorada
                logo = extractValue(line, "tvg-logo=\"(.*?)\"");
                category = extractValue(line, "group-title=\"(.*?)\"");
                
                // 2. Extraer Nombre: Buscamos la última coma
                if (line.contains(",")) {
                    name = line.substring(line.lastIndexOf(",") + 1).trim();
                    // Limpieza: Eliminamos caracteres de control invisibles que rompen el UI
                    name = name.replaceAll("[\\p{Cntrl}&&[^\r\n\t]]", "");
                }
                
                // Si el nombre sigue vacío, usamos la categoría como nombre temporal
                if (name.isEmpty()) name = "Canal sin nombre";

            } else if (line.startsWith("http")) {
                // 3. Si la línea es una URL, validamos y guardamos
                if (!name.isEmpty()) {
                    // Limpiamos la URL de espacios accidentales
                    String cleanUrl = line.replaceAll("\\s+", "");
                    
                    channels.add(new Channel(name, cleanUrl, logo, category));
                    
                    // Reset total para el siguiente bloque
                    name = ""; 
                    logo = "";
                    category = "Sin Categoría";
                }
            }
        }
        return channels;
    }

    private static String extractValue(String line, String regex) {
        try {
            Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
            Matcher matcher = pattern.matcher(line);
            return matcher.find() ? matcher.group(1) : "";
        } catch (Exception e) {
            return "";
        }
    }
}
