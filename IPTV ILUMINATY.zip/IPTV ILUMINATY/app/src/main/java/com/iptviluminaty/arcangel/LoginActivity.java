package com.iptviluminaty.arcangel;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.iptviluminaty.arcangel.databinding.ActivityLoginBinding;

public class LoginActivity extends AppCompatActivity {

    private ActivityLoginBinding binding;
    private static final String PREFS_NAME = "IPTV_PREFS";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        cargarPerfiles();

        binding.btnAddUser.setOnClickListener(v -> {
            String profile = binding.etProfileName.getText().toString().trim();
            String directUrl = binding.etDirectUrl.getText().toString().trim();
            String host = binding.etHost.getText().toString().trim();
            String user = binding.etUser.getText().toString().trim();
            String pass = binding.etPass.getText().toString().trim();

            if (profile.isEmpty()) {
                Toast.makeText(this, "¡Cielo, dale un nombre al perfil! ✨", Toast.LENGTH_SHORT).show();
                return;
            }

            String urlFinal = "";

            if (!directUrl.isEmpty()) {
                urlFinal = directUrl;
            } else if (!host.isEmpty() && !user.isEmpty() && !pass.isEmpty()) {
                urlFinal = host + "/get.php?username=" + user + "&password=" + pass + "&output=m3u_plus";
            }

            if (urlFinal.isEmpty()) {
                Toast.makeText(this, "Completa los datos o pega un enlace 🙄", Toast.LENGTH_SHORT).show();
            } else {
                saveProfile(profile, urlFinal);
            }
        });
    }

    private void saveProfile(String name, String url) {
        SharedPreferences sharedPref = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();

        editor.putString(name + "_url", url);
        
        String currentList = sharedPref.getString("profile_list", "");
        if (!currentList.contains(name)) {
            editor.putString("profile_list", currentList + name + ",");
        }

        editor.apply();
        Toast.makeText(this, "Perfil '" + name + "' guardado 🚀", Toast.LENGTH_SHORT).show();

        binding.containerProfiles.removeAllViews();
        cargarPerfiles();
        
        binding.etProfileName.setText("");
        binding.etDirectUrl.setText("");
        binding.etHost.setText("");
        binding.etUser.setText("");
        binding.etPass.setText("");
    }

    private void cargarPerfiles() {
        SharedPreferences sharedPref = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String lista = sharedPref.getString("profile_list", "");

        if (!lista.isEmpty()) {
            String[] nombres = lista.split(",");
            for (String nombre : nombres) {
                if (!nombre.isEmpty()) {
                    crearBotonDePerfil(nombre);
                }
            }
        }
    }

    private void crearBotonDePerfil(String nombre) {
        Button btn = new Button(this);
        btn.setText(nombre);
        btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#FFD700")));
        btn.setTextColor(Color.BLACK);
        
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 10, 0, 10);
        btn.setLayoutParams(params);

        btn.setOnClickListener(v -> {
            SharedPreferences sp = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            String urlFinal = sp.getString(nombre + "_url", "");
            
            Intent intent = new Intent(this, ChannelListActivity.class); 
            intent.putExtra("URL_FINAL", urlFinal);
            startActivity(intent);
        });

        // 🔥 LÓGICA DE ELIMINACIÓN CON LIMPIEZA DE CACHÉ
        btn.setOnLongClickListener(v -> {
            new android.app.AlertDialog.Builder(this)
                .setTitle("Eliminar Perfil")
                .setMessage("¿Quieres borrar a '" + nombre + "' y su caché? 🗑️")
                .setPositiveButton("Eliminar", (dialog, which) -> {
                    // 1. Limpiamos la caché de disco y RAM (Archivo m3u)
                    ChannelListActivity.clearAllCache(this);
                    
                    // 2. Borramos los datos de SharedPreferences
                    SharedPreferences sp = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                    SharedPreferences.Editor ed = sp.edit();
                    ed.remove(nombre + "_url");
                    String listaActual = sp.getString("profile_list", "");
                    ed.putString("profile_list", listaActual.replace(nombre + ",", ""));
                    ed.apply();
                    
                    // 3. Quitamos el botón de la vista
                    binding.containerProfiles.removeView(btn);
                    Toast.makeText(this, "Perfil y caché eliminados ✨", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancelar", null)
                .show();
            return true; 
        });

        binding.containerProfiles.addView(btn);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        this.binding = null;
    }
}
