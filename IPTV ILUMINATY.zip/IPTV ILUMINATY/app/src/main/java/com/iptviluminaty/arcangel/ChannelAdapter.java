package com.iptviluminaty.arcangel;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.ArrayList; // Importante
import java.util.List;
import java.util.stream.Collectors; // Necesario para Java 17

public class ChannelAdapter extends RecyclerView.Adapter<ChannelAdapter.ViewHolder> {

    private List<Channel> channelsFull;    // La lista original (Copia de seguridad)
    private List<Channel> channelsDisplay; // La lista que se muestra en pantalla
    private OnChannelClickListener listener;

    public interface OnChannelClickListener {
        void onChannelClick(Channel channel);
    }

    public ChannelAdapter(List<Channel> channels, OnChannelClickListener listener) {
        this.channelsFull = new ArrayList<>(channels); // Creamos una copia real
        this.channelsDisplay = channels;
        this.listener = listener;
    }

    // --- ESTE ES EL MÉTODO QUE SOLUCIONA EL ERROR EN LA ACTIVITY ---
    public void filter(String text) {
        if (text.isEmpty()) {
            // Si el buscador está vacío, mostramos todo otra vez
            channelsDisplay = new ArrayList<>(channelsFull);
        } else {
            String filterPattern = text.toLowerCase().trim();
            
            // Usamos Streams de Java 17 (Rápido y moderno)
            channelsDisplay = channelsFull.stream()
                .filter(c -> c.getName().toLowerCase().contains(filterPattern) 
                          || c.getCategory().toLowerCase().contains(filterPattern))
                .collect(Collectors.toList());
        }
        notifyDataSetChanged(); // Refresca la lista en la pantalla
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_channel, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // MUCHO OJO: Aquí usamos channelsDisplay
        Channel channel = channelsDisplay.get(position);
        holder.txtName.setText(channel.getName());
        holder.txtCategory.setText(channel.getCategory());

        Glide.with(holder.itemView.getContext())
                .load(channel.getLogo())
                .placeholder(android.R.drawable.ic_menu_report_image)
                .error(android.R.drawable.ic_menu_gallery) // Logo por defecto si falla el link
                .into(holder.imgLogo);

        holder.itemView.setOnClickListener(v -> listener.onChannelClick(channel));
    }

    @Override
    public int getItemCount() {
        return channelsDisplay.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgLogo;
        TextView txtName, txtCategory;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgLogo = itemView.findViewById(R.id.imgLogo);
            txtName = itemView.findViewById(R.id.txtChannelName);
            txtCategory = itemView.findViewById(R.id.txtCategory);
        }
    }
}
