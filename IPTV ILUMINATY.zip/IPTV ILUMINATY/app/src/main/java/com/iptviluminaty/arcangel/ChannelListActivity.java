package com.iptviluminaty.arcangel;

import android.app.ProgressDialog;
import android.content.Context; // Añadido
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import java.io.*;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ChannelListActivity extends AppCompatActivity {

    private String playlistUrl;
    private RecyclerView recyclerView;
    private ChannelAdapter adapter;
    private ProgressDialog progressDialog;
    
    private static final String CACHE_FILE = "playlist_iluminaty.m3u";
    
    // ✅ Caché en RAM para acceso instantáneo
    private static List<Channel> cachedChannels = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_channel_list);

        recyclerView = findViewById(R.id.recyclerViewChannels);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Procesando canales... ⚡");
        progressDialog.setCancelable(false);

        configurarBuscador();

        playlistUrl = getIntent().getStringExtra("URL_FINAL");
        
        // --- NUEVA LÓGICA DE PRIORIDAD ---
        if (cachedChannels != null && !cachedChannels.isEmpty()) {
            // 1. Si está en RAM, mostrar de inmediato
            mostrarCanales(cachedChannels);
        } else {
            File file = new File(getFilesDir(), CACHE_FILE);
            if (file.exists() && file.length() > 0) {
                // 2. Si está en DISCO, cargar a RAM y mostrar
                cargarDesdeDisco();
            } else if (playlistUrl != null) {
                // 3. Si no hay nada, descargar
                downloadPlaylist();
            }
        }
    }

    // ✅ MÉTODO CLAVE: Llama a esto desde tu LoginActivity al borrar el perfil
    public static void clearAllCache(Context context) {
        // Limpiar RAM
        cachedChannels = null;
        
        // Limpiar DISCO
        File file = new File(context.getFilesDir(), CACHE_FILE);
        if (file.exists()) {
            file.delete();
        }
    }

    private void cargarDesdeDisco() {
        progressDialog.show();
        new Thread(() -> {
            try {
                File file = new File(getFilesDir(), CACHE_FILE);
                FileInputStream fis = new FileInputStream(file);
                BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append("\n");
                }
                fis.close();
                
                cachedChannels = M3UParser.parse(sb.toString()); // Guardar en RAM
                runOnUiThread(() -> mostrarCanales(cachedChannels));
                
            } catch (IOException e) {
                runOnUiThread(() -> downloadPlaylist());
            }
        }).start();
    }

    private void downloadPlaylist() {
        progressDialog.setMessage("Descargando lista... 📥");
        progressDialog.show();

        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(120, TimeUnit.SECONDS)
                .readTimeout(120, TimeUnit.SECONDS)
                .build();

        Request request = new Request.Builder()
                .url(playlistUrl)
                .addHeader("User-Agent", "VLC/3.0.13")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> {
                    progressDialog.dismiss();
                    Toast.makeText(ChannelListActivity.this, "Error de red 📶", Toast.LENGTH_SHORT).show();
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful() && response.body() != null) {
                    byte[] bytes = response.body().bytes();
                    saveToDisk(bytes);
                    
                    String content = new String(bytes, java.nio.charset.StandardCharsets.UTF_8);
                    cachedChannels = M3UParser.parse(content); // Guardar en RAM
                    
                    runOnUiThread(() -> mostrarCanales(cachedChannels));
                }
            }
        });
    }

    private void saveToDisk(byte[] data) {
        try {
            FileOutputStream fos = openFileOutput(CACHE_FILE, MODE_PRIVATE);
            fos.write(data);
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void mostrarCanales(List<Channel> channels) {
        if (progressDialog.isShowing()) progressDialog.dismiss();
        adapter = new ChannelAdapter(channels, channel -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("URL_FINAL", channel.getUrl());
            startActivity(intent);
        });
        recyclerView.setAdapter(adapter);
        Toast.makeText(this, "¡Canales listos! 🚀", Toast.LENGTH_SHORT).show();
    }

    private void configurarBuscador() {
        SearchView searchView = findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) { return false; }
            @Override
            public boolean onQueryTextChange(String newText) {
                if (adapter != null) adapter.filter(newText);
                return true;
            }
        });
    }
}
