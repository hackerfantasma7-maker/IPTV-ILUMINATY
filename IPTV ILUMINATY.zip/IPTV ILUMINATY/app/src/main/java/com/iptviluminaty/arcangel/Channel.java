package com.iptviluminaty.arcangel;

public class Channel {
    private String name;
    private String url;
    private String logo;
    private String category;

    public Channel(String name, String url, String logo, String category) {
        this.name = name;
        this.url = url;
        this.logo = logo;
        this.category = category;
    }

    // Getters necesarios para el Adapter
    public String getName() { return name; }
    public String getUrl() { return url; }
    public String getLogo() { return logo; }
    public String getCategory() { return category; }
}
